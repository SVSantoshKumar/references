create or replace temporary table disha_l2_curated.base_model_data.BOOKING_REPORT_stg as (		
	SELECT 	
	COALESCE(	
		old_loan_account_number,
		cast(new_loan_account_number as varchar)) loan_account_number, 
	customer_id 	
	FROM DISHA_L2_CURATED.HISTORICAL_LOAD.BOOKING_REPORT	
	qualify row_number() over (partition by new_loan_account_number order by extracted_date desc nulls last)=1	
);		
		
create OR REPLACE temporary table disha_l2_curated.base_model_data.CUSTOMER_APP_AUTO_SERVED_prefinal AS (		
SELECT 		
	ls.id as request_id,	
	ls.loan_no,	
	case	
	when ls.event = '/LoanService/loan/welcomeletter' then 'Welcome Letter'	
	when ls.event = '/LoanService/loan/interestCertificate' then 'Interest Certificate'	
	when ls.event =  '/LoanService/loan/provisionalInterestCertificate' then 'Provisional Interest Certificate'	
	when ls.event =  '/LoanService/loan/getPropertyPaper' then 'Copy of Property Paper'	
	end as event,	
	substr(ls.loan_no,length(ls.loan_no)-5,6) as loan_id,	
	br.customer_id,	
	ls.created_at created_date,	
	TO_CHAR(created_at, 'MON-YYYY') AS created_month_year	
FROM 		
	(select id, loan_no, created_at,	
	event	
	from DISHA_L1_HARMONIZED.CUSTOMER_APP.LOAN_SERVICE_API_LOG 	
	where CURRENT_FLAG=TRUE	
	AND event in ('/LoanService/loan/welcomeletter','/LoanService/loan/interestCertificate', '/LoanService/loan/provisionalInterestCertificate',  '/LoanService/loan/getPropertyPaper') 	
	and loan_no not in ('','12345','NA')	
	) ls	
left join disha_l2_curated.base_model_data.BOOKING_REPORT_stg br 		
on LS.LOAN_NO = loan_account_number		
-- where ls.created_at ge '01APR2025'd 		
		
UNION		
		
SELECT 		
	id.id as request_id, 	
	id.LOAN_ID loan_no, 	
	CASE WHEN upper(id.TYPE)= 'LIFE' THEN 'Life Insurance Policy'	
		WHEN upper(id.TYPE) = 'PROPERTY' THEN 'Property Insurance Policy'
		WHEN upper(id.TYPE) = 'HEALTH' THEN 'Health Insurance Policy'
		END AS EVENT,
	substr(id.LOAN_ID,length(id.LOAN_ID)-5,6) as loan_id,	
	br.customer_id,	
	id.created_date,	
	TO_CHAR(TO_DATE(created_date), 'MON-YYYY') AS created_month_year	
FROM 		
    (select ID, LOAN_ID, 		
    TYPE,		
    CREATED_DATE		
    from DISHA_L1_HARMONIZED.CUSTOMER_APP.INSURANCE_DETAILS		
    WHERE CURRENT_FLAG=TRUE		
    AND upper(TYPE) in ('LIFE','PROPERTY','HEALTH')		
    ) id 		
left join disha_l2_curated.base_model_data.BOOKING_REPORT_stg br  		
on ID.LOAN_ID = loan_account_number		
)		
;		
