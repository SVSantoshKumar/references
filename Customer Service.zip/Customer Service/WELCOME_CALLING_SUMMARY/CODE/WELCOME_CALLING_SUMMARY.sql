CREATE OR REPLACE TEMPORARY TABLE DISHA_L2_CURATED.BASE_HARDCODE.elision_union_STG as	
(SELECT 	
a.*,	
b.entry_date,	
b.status,	
b.called_count, 	
'Gujarat' as wc_state,	
case 	
    when a.venderleadcode1 like '%''%' then replace(a.venderleadcode1,'''','')	
    else a.venderleadcode1 end as loan_no,	
CASE 	
    WHEN TRY_TO_DATE(disdate, 'YYYY-MM-DD') IS NOT NULL THEN TRY_TO_DATE(disdate, 'YYYY-MM-DD')	
    WHEN TRY_TO_DATE(disdate, 'DDMONYYYY') IS NOT NULL THEN TRY_TO_DATE(disdate, 'DDMONYYYY')	
    ELSE NULL	
    END AS first_disbursal_date,	
case 	
    when b.status = 'NEW' then null	
    else b.last_local_call_time 	
    end call_date	
FROM DISHA_L1_HARMONIZED.DIALER.ELISION_15102024 AS a	
LEFT JOIN DISHA_L1_HARMONIZED.DIALER.ELISION_LIST AS b 	
ON a.lead_id = b.lead_id	
and b.current_flag=true	
where VENDERLEADCODE1 not in ('','12345', '.',' ') and trim(VENDERLEADCODE1) is not null	
and status !='' and status is not null	
	
union 	
	
SELECT 	
a.*,	
b.entry_date,	
b.status,	
b.called_count,	
'Karnataka' as wc_state,	
case when a.venderleadcode1 like '%''%'	
then replace(a.venderleadcode1,'''','') else a.venderleadcode1 end as loan_no,	
CASE 	
    WHEN TRY_TO_DATE(disdate, 'YYYY-MM-DD') IS NOT NULL THEN TRY_TO_DATE(disdate, 'YYYY-MM-DD')	
    WHEN TRY_TO_DATE(disdate, 'DDMONYYYY') IS NOT NULL THEN TRY_TO_DATE(disdate, 'DDMONYYYY')	
    ELSE NULL	
  END AS first_disbursal_date,	
case	
    when b.status = 'NEW' then null	
    else b.last_local_call_time 	
    end call_date	
FROM DISHA_L1_HARMONIZED.DIALER.ELISION_15102043 AS a	
LEFT JOIN DISHA_L1_HARMONIZED.DIALER.ELISION_LIST AS b 	
ON a.lead_id = b.lead_id 	
and b.current_flag=true	
where VENDERLEADCODE1 not in ('','12345', '.',' ') and trim(VENDERLEADCODE1) is not null	
and status !='' and status is not null	
	
union 	
	
SELECT 	
a.*,	
b.entry_date,	
b.status,	
b.called_count,	
'ROA' as wc_state,	
case when a.venderleadcode1 like '%''%'	
then replace(a.venderleadcode1,'''','') else a.venderleadcode1 end as loan_no,	
CASE 	
    WHEN TRY_TO_DATE(disdate, 'YYYY-MM-DD') IS NOT NULL THEN TRY_TO_DATE(disdate, 'YYYY-MM-DD')	
    WHEN TRY_TO_DATE(disdate, 'DDMONYYYY') IS NOT NULL THEN TRY_TO_DATE(disdate, 'DDMONYYYY')	
    ELSE NULL	
  END AS first_disbursal_date,	
case 	
    when b.status = 'NEW' then null	
else b.last_local_call_time end call_date	
FROM DISHA_L1_HARMONIZED.DIALER.ELISION_15102045 AS a	
LEFT JOIN DISHA_L1_HARMONIZED.DIALER.ELISION_LIST AS b 	
ON a.lead_id = b.lead_id 	
and b.current_flag=true	
where VENDERLEADCODE1 not in ('','12345', '.',' ') and trim(VENDERLEADCODE1) is not null	
and status !='' and status is not null	
);	
	
CREATE OR REPLACE TABLE DISHA_L2_CURATED.BASE_HARDCODE.WELCOME_CALLING_SUMMARY AS (	
select 	
loan_no, 	
first_disbursal_date,	
case when status in ('N') then 'No Answer'	
when status in ('PDROP') then 'Outbound Pre-Routing Drop'	
when status in ('NIS') then 'No Issue'	
when status in ('ROI') then 'ROI Issue'	
when status in ('OIS') then 'Other Issue'	
when status in ('CDC') then	'Call Disconnect by customer'
when status in ('DROP') then 'Agent Not Available'	
when status in ('EMIP') then 'EMI Problem'	
when status in ('Topup') then 'Top-Up Related'	
when status in ('ADC')	then 'Disconnected Number Auto'
when status in ('ALC') then	'Already Loan Closed'
when status in ('RS')	then 'Repayment Schedule'
when status in ('PLRIss') then 'PLR Issue'	
when status in ('WR') then 'Wrong Number'	
when status in ('FCS') then 'FC Statement'	
when status in ('PP') then 'Part Payment'	
when status in ('AB') then 'Busy Auto'	
when status in ('IP') then 'Insurance Policy'	
when status in ('Subsid') then 'Subsidy Related'	
when status in ('DDRDue') then 'Due Date'	
when status in ('TP') then 'Tenure Problem'	
when status in ('CWF')	then 'Customer want to foreclosed'
when status in ('NCHU')	then 'Call Hung Up'
when status in ('DNC') then	'Do Not Call'
when status in ('INCALL') then	'Lead Being Called'
when status in ('ITC')	then 'IT Certificate'
when status in ('LDR') then	'Loan Details Required'
when status in ('QUEUE') then 'Lead To Be Called'	
when status in ('RR') then 'Refund Related'	
when status in ('Swappi') then 'Swapping'	
when status in ('SOA') then	'SOA'
when status in ('Insura') then 'Insurance Related'	
when status in ('DCR') then	'Disbursement Cheque Related'
when status in ('AFTHRS') then 'Inbound After Hours Drop'	
when status in ('Close') then 'Close'	
when status in ('TST') then	'Transferred_Sales Team'
when status in ('A') then 'Answering Machine'	
when status in ('WIPH') then 'WIP-HO'	
when status in ('TIMEOT') then 'Inbound Queue Timeout Drop'	
when status in ('XFER')	then 'Call Transferred'
when status in ('TCCT')	then 'Transferred_CustomerC Team'
when status in ('WIPB')	then 'WIP-Branch'
when status in ('NR') then 'No Reply'	
when status in ('DISPO') then 'Full Form'	
when status in ('WIPC') then 'WIP-CC'	
when status in ('WL') then 'Welcome Letter'	
when status in ('BM') then 'Bouncing Memo'	
when status in ('PCPP')	then 'Photo Copy of Property Papers'
when status in ('NA') then 'No Answer AutoDial'	
when status in ('LC') then 'Loan cancel' 	
when status in ('ERI') then 'Agent Error'	
when status in ('PU') then 'Call Picked Up'	
when status in ('CALLBK') then 'Call Back'	
when status in ('CCCB') then 'CC - Call Back'	
when status in ('IC') then 'Informed to customer'	
when status in ('NOR') then 'Not Reachable'	
when status in ('OC') then 'Out Of Coverage'	
when status in ('SO') then 'Switched Off'	
when status in ('CBHOLD') then 'Call Back Hold'	
when status in ('DT') then 'NO Sound Dial Time Out'	
when status in ('Discon') then 'Discon'	
when status in ('LCR') then 'Loan Cancellation Related'	
when status in ('LOC') then 'Loan cancelled'	
when status in ('NC') then 'Not Contactable'	
when status in ('NEW') then 'New Lead'	
when status in ('NI') then 'Not Interested'	
when status in ('NIB') then 'Number Is Busy'	
when status in ('NOS') then 'Number not in Service'	
when status in ('NUM') then 'Number Does Not Exist'	
when status in ('TD') then 'Temporary Disconnected'	
else status end as Status_desc,	
case when status in ('NI','LOC','LCR','IC','NIS','ROI','OIS','EMIP','Topup','ALC','RS',	
'PLRIss','FCS','PP','IP','Subsid','DDRDue','TP','CWF','ITC','LDR','RR','Swappi',	
'SOA','Insura','DCR','Close','WL','BM','PCPP','LC')	
then 'Connect'	
when status in ('TD','NUM','NOS','NIB','NC','Discon','DT','CBHOLD','SO','OC','NOR','CCCB','CALLBK',	
'N','ERI','PDROP','CDC','DROP','ADC','WR','AB','NCHU','DNC','INCALL','QUEUE','AFTHRS','A','WIPH',	
'TIMEOT','WIPB','NR','DISPO','WIPC','NA','PU','ISNA','CNPUTC')	
then 'Not Connect'	
when status = 'NEW' then 'Pending'	
when status in ('XFER') then 'Call Transferred'	
when status in ('TCCT') then 'Transferred_CustomerC Team'	
when status in ('TST') then 'Transferred_Sales Team'	
else status	
end as Response,	
called_count, 	
entry_date, 	
wc_state,	
call_date	
from DISHA_L2_CURATED.BASE_HARDCODE.elision_union_STG	
QUALIFY ROW_NUMBER() OVER (PARTITION BY loan_no ORDER BY call_date desc) = 1	
);	
